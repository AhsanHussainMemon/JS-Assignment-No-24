function showSignup() {
    document.getElementById("loginForm").style.display = "none";
    document.getElementById("signupForm").style.display = "block";
}

function showLogin() {
    document.getElementById("signupForm").style.display = "none";
    document.getElementById("loginForm").style.display = "block";
}

function handleSignup() {
    var username = document.getElementById("signupUsername").value;
    var phone = document.getElementById("signupPhone").value;
    var password = document.getElementById("signupPassword").value;

    if (username && phone && password) {
        localStorage.setItem("Email", username);
        localStorage.setItem("Password", password);
        localStorage.setItem("Phone Number", phone);
        Swal.fire({
            title: "Account Created!",
            text: "Your account has been created successfully.",
            icon: "success",
            backdrop: true,
            willClose: function() {
                showLogin();  
            }
        });
    } else {
        Swal.fire({
            title: "Error",
            text: "Please fill all fields!",
            icon: "error"
        });
    }
}

function handleLogin() {
    var username = document.getElementById("loginUsername").value;
    var password = document.getElementById("loginPassword").value;

    var storedPassword = localStorage.getItem("Password");
    var storedUsername = localStorage.getItem("Email");

    if (storedUsername === username && storedPassword === password) {
        Swal.fire({
            title: "Login Successful!",
            text: "Welcome back!",
            icon: "success",
            backdrop: true
        });
    } else {
        Swal.fire({
            title: "Error",
            text: "Invalid username or password.",
            icon: "error"
        });
    }
}
